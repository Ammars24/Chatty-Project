public class GetAllPostsTest {
}
