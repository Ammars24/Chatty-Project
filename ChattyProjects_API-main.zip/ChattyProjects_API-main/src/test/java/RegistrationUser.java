import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.junit.jupiter.api.Assertions.*;

public class RegistrationUser extends BaseTest{
//    @Test
//    public void successRegister() {
//        RegisterRequest requestBody = new RegisterRequest("testQA303@gmail.com", "Test123456", "Test123456", "user");
//
//        SuccessRegisterResponse response = given().baseUri("http://chatty.telran-edu.de:8989/")
//                .when().log().all()
//                .contentType(ContentType.JSON)
//                .body(requestBody)
//                .post("api/auth/register")
//                .then().log().all()
//                .statusCode(201)
//                .extract().body().jsonPath().getObject("", SuccessRegisterResponse.class);
//
//        // Проверяем, что response не null
//        assertNotNull(response);
//
//        // Выводим id для проверки
//        System.out.println("User ID: " + response.getId());
//
//        // Проверка на то, что accessToken не пустой
//        assertNotNull(response.getAccessToken(), "Access Token should not be null");
//        assertFalse(response.getAccessToken().isEmpty(), "Access Token should not be empty");
//
//        // Если нужно, можно также проверить refreshToken
//        assertNotNull(response.getRefreshToken(), "Refresh Token should not be null");
//        assertFalse(response.getRefreshToken().isEmpty(), "Refresh Token should not be empty");
//    }
//    @Test
//    public void registerWithoutPassword() {
//        RegisterRequest requestBody = new RegisterRequest("testQA2041@gmail.com", "", "", "user");
//
//        // Отправка запроса на регистрацию с пустыми полями пароля и подтверждения пароля
//        ErrorRegisterResponse response = given().baseUri("http://chatty.telran-edu.de:8989/")
//                .when().log().all()
//                .contentType(ContentType.JSON)
//                .body(requestBody)
//                .post("api/auth/register")
//                .then().log().all()
//                .statusCode(400)
//                .extract().body().jsonPath().getObject("", ErrorRegisterResponse.class);
//
//        // Проверка, что ошибки для пароля и подтверждения пароля присутствуют
//        assertTrue(response.getErrors().containsKey("password"));
//        assertTrue(response.getErrors().containsKey("confirmPassword"));
//
//        // Логируем ошибки
//        System.out.println(response.getErrors());
//    }

    @Test
    public void successCreatedUser (){
        CreateUserRequest createUserRequest = new CreateUserRequest("John","testQA303@gmail.com", "Test123456", "Test123456", "user");
        Response response = postRequest ("/api/auth/register", 201, createUserRequest);

        CreateUserResponse createUserResponseBody = response.as(CreateUserResponse.class);
        assertFalse(createUserResponseBody.getAccessToken().isEmpty());
        assertFalse(createUserResponseBody.getRefreshToken().isEmpty());
        assertNotNull(createUserResponseBody.getExpiration());

    }
    @Test
    public void successCreatedAdmin (){
        CreateUserRequest createUserRequest = new CreateUserRequest("JohnAdmin","AdminTestQA303@gmail.com", "Test123456", "Test123456", "admin");
        Response response = postRequest ("/api/auth/register", 201, createUserRequest);

        CreateUserResponse createUserResponseBody = response.as(CreateUserResponse.class);

        //Check that Access token, refresh token and expiration are not empty
        assertFalse(createUserResponseBody.getAccessToken().isEmpty());
        assertFalse(createUserResponseBody.getRefreshToken().isEmpty());
        assertNotNull(createUserResponseBody.getExpiration());

    }

    }

