import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

public class UpdatePasswordTest extends BaseTest {
    @Test
    public void updatePassword() {
        String password = "";
        String passwordNew = "";
        LoginUserRequest loginUserRequest = new LoginUserRequest("", password);
        Response response = postRequest("/api/auth/login", 200, loginUserRequest);
        LoginUserResponse responseBodyLogin = response.as(LoginUserResponse.class);
        String token = responseBodyLogin.getAccessToken();

        UpdatePasswordRequest updatePasswordRequest = new UpdatePasswordRequest(password, passwordNew, passwordNew);
        Response updatePasswordResponse = putRequest("/api/user/password/update", 200, updatePasswordRequest, token);

        
    }
}
