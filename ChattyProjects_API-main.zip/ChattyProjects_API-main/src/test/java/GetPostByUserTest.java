import org.junit.jupiter.api.Test;

public class GetPostByUserTest {
    @Test
    public void getPostByUser(){

    }
}
