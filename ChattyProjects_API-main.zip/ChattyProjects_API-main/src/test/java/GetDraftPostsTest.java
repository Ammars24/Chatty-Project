public class GetDraftPostsTest {
}
