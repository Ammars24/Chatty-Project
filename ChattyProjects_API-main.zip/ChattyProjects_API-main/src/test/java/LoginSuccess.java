import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.junit.jupiter.api.Test;

public class LoginSuccess extends BaseTest {
//    @Test
//    public void loginSuccessful() {
//        String email = "testQA303@gmail.com";
//        String password = "Test123456";
//
//        // Отправка запроса на логин
//        given()
//                .baseUri("http://chatty.telran-edu.de:8989/")
//                .contentType(ContentType.JSON)
//                .body("{ \"email\": \"" + email + "\", \"password\": \"" + password + "\" }")
//                .when()
//                .post("api/auth/login")
//                .then()
//                .statusCode(200) // Проверка, что статус код успешный
//                .body("message", is(emptyOrNullString())); // Проверка, что поле message пустое или null
//    }
    @Test
    public void successLoginUser (){
        LoginUserRequest loginUserRequest = new LoginUserRequest("testQA303@gmail.com", "Test123456");
        Response response = postRequest("/api/auth/login", 200, loginUserRequest);
        LoginUserResponse responseBodyLogin = response.as(LoginUserResponse.class);

        assertFalse(responseBodyLogin.getAccessToken().isEmpty());
        assertFalse(responseBodyLogin.getRefreshToken().isEmpty());
        assertNotNull(responseBodyLogin.getExpiration());
    }
    @Test
    public void successLoginAdmin (){
        LoginUserRequest loginUserRequest = new LoginUserRequest("AdminTestQA303@gmail.com", "Test123456");
        Response response = postRequest("/api/auth/login", 200, loginUserRequest);
        LoginUserResponse responseBodyLogin = response.as(LoginUserResponse.class);

        assertFalse(responseBodyLogin.getAccessToken().isEmpty());
        assertFalse(responseBodyLogin.getRefreshToken().isEmpty());
        assertNotNull(responseBodyLogin.getExpiration());
    }

}
